# from flask import Flask, render_template, request, redirect
# app = Flask(__name__)

# @app.route('/')
# def index():
#   return render_template("index.html")

# @app.route('/users', methods=['POST'])
# def create_user():
#    print "Submitted Info"
#    Name = request.form['name']
#    # Dojo Location = request.form['DC', 'Chicago', 'SanJose']
#    # Favorite Language = request.form['Javascript', 'Python', 'Ruby']
#    Comment = request.form['comments']

#    return redirect('/users')


# app.run(debug=True) 

from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route('/')
def survey():
    return render_template('index.html')
@app.route('/submit', methods = ['POST'])
def results():
    data = request.form
    # print data
    return render_template('users.html', data=data)

app.run(debug=True)